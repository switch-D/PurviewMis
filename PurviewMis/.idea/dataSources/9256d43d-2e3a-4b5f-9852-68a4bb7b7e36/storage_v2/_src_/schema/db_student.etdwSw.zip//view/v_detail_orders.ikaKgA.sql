create view v_detail_orders as
select `db_student`.`detail_orders`.`OrderId`                                           AS `OrderId`,
       `db_student`.`detail_orders`.`ProductId`                                         AS `productId`,
       `db_student`.`products`.`ProductName`                                            AS `ProductName`,
       `db_student`.`detail_orders`.`quantity`                                          AS `quantity`,
       `db_student`.`detail_orders`.`price`                                             AS `price`,
       (`db_student`.`detail_orders`.`price` *
        `db_student`.`detail_orders`.`quantity`)                                        AS `price*detail_orders.quantity`
from `db_student`.`products`
         join `db_student`.`detail_orders`
where (`db_student`.`products`.`productId` = `db_student`.`detail_orders`.`ProductId`);

